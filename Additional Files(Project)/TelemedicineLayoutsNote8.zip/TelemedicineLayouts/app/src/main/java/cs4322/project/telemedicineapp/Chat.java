package cs4322.project.telemedicineapp;

import android.os.Bundle;
import android.app.Activity;

public class Chat extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
    }

}
