package cs4322.project.telemedicineapp;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Iterator;

import cs4322.project.telemedicineapp.model.Doctor;
import cs4322.project.telemedicineapp.model.Patient;

public class chatList extends AppCompatActivity {

    ListView usersList;
    TextView noUsersText;
    ArrayList<String> al = new ArrayList<>();
    int totalUsers = 0;
    ProgressDialog pd;
    private FirebaseAuth auth;
    private DatabaseReference appDatabase;
    //private String url = "https://senior-project-9c4ce.firebaseio.com/patients.json";
    private String url;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat_list);

        auth = FirebaseAuth.getInstance();
        appDatabase = FirebaseDatabase.getInstance().getReference();
        final FirebaseUser user = auth.getCurrentUser();
        usersList = (ListView)findViewById(R.id.usersList);
        noUsersText = (TextView)findViewById(R.id.noUsersText);

        pd = new ProgressDialog(chatList.this);
        pd.setMessage("Loading...");
        pd.show();

        //if (auth.getCurrentUser())
            /*appDatabase.child("patients").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    //Patient pt = dataSnapshot.getValue(Patient.class);
                    //Toast.makeText(LoginActivity.this, pt.toString(), Toast.LENGTH_SHORT).show();
                    //System.out.println(pt);

                    if (dataSnapshot.hasChild(user.getUid())) {
                        String url = "https://senior-project-9c4ce.firebaseio.com/patients.json";
                        //String usernameStr = username.getText().toString();
                        //intent.putExtra("name")
                    } else {
                        String url = "https://senior-project-9c4ce.firebaseio.com/Doctors.json";
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }});*/
        /*appDatabase.child("patients").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (snapshot.hasChild(user.getUid())) {
                    url = "https://senior-project-9c4ce.firebaseio.com/patients.json";
                }
                else
                    url = "https://senior-project-9c4ce.firebaseio.com/Doctors.json";
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });*/
        if (Login.USER_PROFILE.equalsIgnoreCase("p"))
            url = "https://senior-project-9c4ce.firebaseio.com/Doctors.json";
        else
            url = "https://senior-project-9c4ce.firebaseio.com/patients.json";

                //String url = "https://senior-project-9c4ce.firebaseio.com/Doctors.json";

        StringRequest request = new StringRequest(Request.Method.GET, url, new Response.Listener<String>(){
            @Override
            public void onResponse(String s) {
                doOnSuccess(s);
            }
        },new Response.ErrorListener(){
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                System.out.println("" + volleyError);
            }
        });

        RequestQueue rQueue = Volley.newRequestQueue(chatList.this);
        rQueue.add(request);

        usersList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                UserChatDetails.chatWith = al.get(position);
                startActivity(new Intent(chatList.this, Chat.class));
            }
        });
    }

    public void doOnSuccess(String s){
        try {
            JSONObject obj = new JSONObject(s);

            Iterator i = obj.keys();
            String key = "";

            while(i.hasNext()){
                key = i.next().toString();

                if(!key.equals(UserChatDetails.username)) {
                    JSONObject user = (JSONObject)obj.get(key);
                    al.add(user.getString("fullname"));
                }

                totalUsers++;
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

        if(totalUsers <=1){
            noUsersText.setVisibility(View.VISIBLE);
            usersList.setVisibility(View.GONE);
        }
        else{
            noUsersText.setVisibility(View.GONE);
            usersList.setVisibility(View.VISIBLE);
            usersList.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, al));
        }

        pd.dismiss();
    }

    private String getUsername (final String key){
        final String[] name = new String[1];
            String child;
            if (Login.USER_PROFILE.equalsIgnoreCase("p"))
                child = "patients";
            else
                child = "Doctors";
        //if (url.equalsIgnoreCase("https://senior-project-9c4ce.firebaseio.com/patients.json")){
            //return appDatabase.child("patients").child(key).child("fullname").toString();
            appDatabase.child(child).child(key).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot snapshot) {
                    if (Login.USER_PROFILE.equalsIgnoreCase("p")) {

                        Patient pt = snapshot.getValue(Patient.class);
                        if (pt != null)
                           name[0] = pt.getusername();
                    }
                    else {
                        Doctor doc = snapshot.getValue(Doctor.class);
                        if (doc != null)
                           name[0] = doc.getUsername();
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
            return name[0];
        //}
        //return appDatabase.child("Doctors").child(key).child("fullname").getKey();
    }
}
