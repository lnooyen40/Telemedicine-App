package cs4322.project.telemedicineapp;

public class UserChatDetails {
    static String username = "";
    static String password = "";
    static String chatWith = "";
}
