package cs4322.project.telemedicineapp;

import android.content.Intent;
import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.widget.Button;

public class RoleSelectionActivity extends Activity {

    private Button backBtn;
    private Button patientBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_role_selection);

        backBtn = (Button) findViewById(R.id.backBtn);
        patientBtn = (Button) findViewById(R.id.patientBtn);

        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(RoleSelectionActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });

        patientBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(RoleSelectionActivity.this, PatientRegistrationActivity.class);
                startActivity(intent);
            }
        });
    }

}
