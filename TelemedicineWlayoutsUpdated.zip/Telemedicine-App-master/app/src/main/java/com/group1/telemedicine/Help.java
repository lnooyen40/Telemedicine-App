package com.group1.telemedicine;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Help extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help);

        // Currently just a single text view, we can make a
        // standard FAQ to put in a text view to be displayed




    }
}
